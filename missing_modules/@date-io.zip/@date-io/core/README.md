## Date-io core

This project is a part of [date-io monorepo](https://github.com/dmtrKovalenko/date-io). This particular package contains an implemented interface (typescript declaration) for all available implementations.

Get more information [here](https://github.com/dmtrKovalenko/date-io)
