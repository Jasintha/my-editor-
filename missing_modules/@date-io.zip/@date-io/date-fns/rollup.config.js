import typescript from 'typescript'
import { createRollupConfig } from '@date-io/core/dev-utils'

export default createRollupConfig(typescript)
