declare module "@date-io/type" {
  export type DateType = Date;
}
