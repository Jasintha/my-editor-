## Date-io adapter for date-fns

This project is a part of [date-io monorepo](https://github.com/dmtrKovalenko/date-io) and contains the unified interface of date-fns.

Get more information [here](https://github.com/dmtrKovalenko/date-io)
